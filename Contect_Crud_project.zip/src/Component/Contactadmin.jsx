import React, { useEffect, useState } from 'react';
import { Formik, Field, Form,ErrorMessage  } from 'formik';
import * as Yup from "yup";
import axios from 'axios';
import AOS from 'aos';
import 'aos/dist/aos.css';

const SignupSchema = Yup.object().shape({
    firstname: Yup.string().min(2, 'Too Short!').max(70, 'Too Long!').required('Required'),
    lastname: Yup.string().min(2, 'Too Short!').max(70, 'Too Long!').required('Required'),
     contact: Yup.string().min(2, 'Too Short!').max(70, 'Too Long!').required('Required'),
     state: Yup.string().min(2, 'Too Short!').max(70, 'Too Long!').required('Required'),
     district: Yup.string().min(2, 'Too Short!').max(70, 'Too Long!').required('Required'),
});

  // let TOKEN="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2MGZiYjBlOTNhNWFjOWFiNjdlMDMzOCIsImlhdCI6MTcxMjMyMDAyMH0.6dBeehwQAMgOBhmFgdk-3LQKWLuWpqxZgbIqkASiLzw"  

  
  
  const Contactadmin = () => {
  let TOKAN=localStorage.getItem('Text')
    let [Text,SetText]=useState([])
    let [initialValues,SetInitialvalues]=useState({firstname:'',lastname:'',contact:'',state:'',district:''})
    let [Edit,SetEdit]=useState(null)



    let GETDATA =()=>{
      axios.get("https://contact-api-lz03.onrender.com/api/contect/find",
      {
         headers:
         {
          usertoken:TOKAN
         }
      })
      .then((res)=>{
        console.log(res);
        SetText(res.data.data)
      })
      .catch((err)=>{
        console.log(err);
      })

    }
    useEffect(()=>{
      GETDATA()
      AOS.init();
    })
   let DELETE_HENDLER=(_id)=>{

    axios.delete("https://contact-api-lz03.onrender.com/api/contect/delete?id="+_id,{
      headers:{
        usertoken:TOKAN
      }
    })
    .then((res)=>{
      console.log(res);
      GETDATA()
    })
    .catch((err)=>{
      console.log(err);
    })
   }
   let EDIT_HENDLER=(el,_id)=>{
   SetInitialvalues(el)
   SetEdit(_id)


   }


    
return (
    <div>
         <div >
         <div className='container'>
            <div className="container-fluid">
            <Formik
            initialValues={initialValues}
            enableReinitialize
            validationSchema={SignupSchema}
  
      onSubmit={async (values,action) => {

        if(Edit !==null){
          axios.patch("https://contact-api-lz03.onrender.com/api/contect/update?id="+Edit,values,{
            headers:{
              usertoken:TOKAN
            }

          })
          .then((res)=>{
            console.log(res);
            GETDATA()
            SetEdit(null)
          })
          .catch((err)=>{
            console.log(err);
            
          })
        }
        else{
          let TOKEN=localStorage.getItem('Text')
          axios.post("https://contact-api-lz03.onrender.com/api/contect/create",values,
          {
           headers:{
               usertoken:TOKAN
           }
          })
          .then((res)=>{
           console.log(res);
           SetText()
           alert("Contact is sucssesfully")
          })
          .catch((err)=>{
           console.log(err);
           alert("not valid")
          })

        }
        SetInitialvalues({firstname:'',lastname:'',contact:'',state:'',district:''})
      
        action.resetForm()
       
      }}
    >
    
        <div className='w-100 d-flex  align-items-center'>

        
      <Form className='border border-black back-side fs-5 mt-5' data-aos="fade-up">
        <div className='text-center mb-5 text-black'>
            <h3>CONTACT ADMIN FORM</h3>

        </div>
        <div className='mb-3'>
        <label htmlFor="firstname" className='line text-black'>first Name <ErrorMessage name="firstname" component={'p'} className='error' /></label>
        <Field  className="logo" id="firstname" name="firstname" placeholder="firstname" />
        </div>
        <div className='mb-3'>
        <label htmlFor="lastname" className='line text-black'>last Name<ErrorMessage name="lastname" component={'p'} className='error' /></label>
        <Field  className="logo" id="lastname" name="lastname" placeholder="lastname" />
        </div>
        
        <div className='mb-3'>
        <label htmlFor="contact" className='line text-black'>contact <ErrorMessage name="contact" component={'p'} className='error' /></label>
        <Field  className="logo"id="contact" name="contact" placeholder="contact" />
        </div>

        <div className='mb-3'>
        <label htmlFor="state" className='line text-black'>state <ErrorMessage name="state" component={'p'} className='error' /></label>
        <Field  className="logo"id="state" name="state" placeholder="state" />
        </div> 
        <div className='mb-5'>
        <label htmlFor="district" className='line text-black'>District <ErrorMessage name="district" component={'p'} className='error' /></label>
        <Field  className="logo"id="district" name="district" placeholder="district" />
        </div>
        <div className='d-flex justify-content-center gap-5 '>
         <button type="submit" className='px-5 bg1 text-white ' >SUBMIT</button>
         <button type='reset' className='px-5 bg1 text-white '>RESET</button>
        </div>



      </Form>
      <table border={1} width={'100%'} className='mt-5 color' >
        <tr style={{height:"40px",textAlign:'center'}}>
            <th className='border '>Index</th>
            <th className='border'>firstname</th>
            <th className='border'>lastname</th>
            <th className='border'>contact</th>
            <th className='border'>state</th>
            <th className='border'>district</th>
            <th className='border '>DELETE</th>
            <th className='border'>EDIT</th>
        </tr>

        {
          Text.map((el,index)=>{
            return(
              <tr key={index}>
                <td className='border'>{index +1}</td>
                <td className='border'>{el.firstname}</td>
                <td className='border'>{el.lastname}</td>
                <td className='border'>{el.contact}</td>
                <td className='border'>{el.state}</td>
                <td className='border'>{el.district}</td>
                <td>
                  <button style={{display:'flex',alignItems:'center'}} onClick={()=>DELETE_HENDLER(el._id)}>DELETE</button>
                
                </td>
                <td>  <button onClick={()=>EDIT_HENDLER(el,el._id)}>EDIT</button></td>
              </tr>
            )
          })
        }
    
      </table>

   
      </div>
    </Formik>

            </div>

        </div>
      
      
    </div>
      
    </div>
  )
}

export default Contactadmin
