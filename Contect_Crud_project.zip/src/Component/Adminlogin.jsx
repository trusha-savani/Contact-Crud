import React from 'react'
import { Formik, Field, Form,ErrorMessage  } from 'formik';
import * as Yup from "yup";
import axios from 'axios';
import AOS from 'aos';
import 'aos/dist/aos.css';
import { useEffect } from 'react';
import { Link } from 'react-router-dom/cjs/react-router-dom.min';


const SignupSchema = Yup.object().shape({
    
    username: Yup.string().min(2, 'Too Short!').max(70, 'Too Long!').required('Required'),
    password: Yup.string().min(2, 'Too Short!').max(70, 'Too Long!').required('Required'),
});



const Adminlogin = () => {
  useEffect(()=>{
    AOS.init();
  },[])
  return (
    <div>
        <div className='container'>
            <div className="container-fluid">
            <Formik
      initialValues={{
       username:'',
        password:'',
    }}
      validationSchema={SignupSchema}
      onSubmit={async (values,action) => {

        axios.post("https://contact-api-lz03.onrender.com/api/admin/login",values)
        .then((res)=>{
            console.log(res);
            alert("User Login sucssesfully")
        })
        .catch((err)=>{
            console.log(err);
            alert("not valid")
        })
        action.resetForm()
      
      }}
    >
        <div className='w-100 d-flex justify-content-center align-items-center'>

        <div className='box'>

        
      <Form className='border border-black back-side fs-5'data-aos="fade-left">
        <div className='text-center text-black mb-5'>
            <h3>ADMIN LOGIN IN FORM</h3>

        </div>
        <div className='mb-3'>
        <label htmlFor="username" className='line text-black'>Username <ErrorMessage name="username" component={'p'} className='error' /></label>
        <Field  className="logo"id="username" name="username" placeholder="Username" />
        </div>
        <div className='mb-5'>
        <label htmlFor="password" className='line text-black'>Password <ErrorMessage name="password" component={'p'} className='error' /></label>
        <Field  className="logo"id="password" name="password" placeholder="Password" />
        </div>
        <div className='d-flex justify-content-center gap-5 '>
        <button type="submit" className='px-5 bg1 text-white rounded-5' style={{width:'100%'}} >ADMIN LOGIN</button> 
       
        </div>
        <div className='mt-2'>
        <button type='reset' className='px-5 bg1 text-white  rounded-5'style={{width:'100%'}}>RESET</button>
        </div>
        <div className='d-flex align-items-center mt-2'>
          <input type="checkbox" />
          <p className='m-2'>i agree to the <strong className='text-primary'>Terms & Condition</strong>
          </p>
        </div>
        <div className='d-flex justify-content-center '>
          <a href=""> Already have an account?<Link to='/Adminsignuppage' className='text-primary' >ADMIN SIGN UP</Link></a>
        </div>



      </Form>
      </div>
      </div>
    </Formik>

            </div>

        </div>
      
      
    </div>
  )
}

export default Adminlogin
