import React from 'react'
import { Formik, Field, Form,ErrorMessage  } from 'formik';
import * as Yup from "yup";
import axios from 'axios';
const SignupSchema = Yup.object().shape({
    firstname: Yup.string().min(2, 'Too Short!').max(70, 'Too Long!').required('Required'),
    lastname: Yup.string().min(2, 'Too Short!').max(70, 'Too Long!').required('Required'),
     contact: Yup.string().min(2, 'Too Short!').max(70, 'Too Long!').required('Required'),
     state: Yup.string().min(2, 'Too Short!').max(70, 'Too Long!').required('Required'),
     district: Yup.string().min(2, 'Too Short!').max(70, 'Too Long!').required('Required'),
});

const Contactcreact = () => {
  return (
    <div className='bg'>
         <div className='container'>
            <div className="container-fluid">
            <Formik
      initialValues={{
        firstname: '',
        lastname: '',
        state:'',
        district:'',
    }}
      validationSchema={SignupSchema}
      onSubmit={async (values,action) => {

        axios.post("https://contact-api-lz03.onrender.com/api/admin/signup",values)
        .then((res)=>{
            console.log(res);
            alert("User Login sucssesfully")
        })
        .catch((err)=>{
            console.log(err);
            alert("not valid")
        })
        action.resetForm()
      
      }}
    >
        <div className='w-100 d-flex justify-content-center align-items-center'>

        
      <Form className='border border-black back-side fs-5'>
        <div className='text-center mb-5 text-white'>
            <h3>CONTACT CREACT FORM</h3>

        </div>
        <div className='mb-3'>
        <label htmlFor="firstname" className='line text-white'>first Name <ErrorMessage name="firstname" component={'p'} className='error' /></label>
        <Field  className="logo" id="firstname" name="firstname" placeholder="firstname" />
        </div>
        <div className='mb-3'>
        <label htmlFor="lastname" className='line text-white'>last Name<ErrorMessage name="lastname" component={'p'} className='error' /></label>
        <Field  className="logo" id="lastname" name="lastname" placeholder="lastname" />
        </div>
        
        <div className='mb-3'>
        <label htmlFor="contact" className='line text-white'>contact <ErrorMessage name="contact" component={'p'} className='error' /></label>
        <Field  className="logo"id="contact" name="contact" placeholder="contact" />
        </div>

        <div className='mb-3'>
        <label htmlFor="state" className='line text-white'>state <ErrorMessage name="state" component={'p'} className='error' /></label>
        <Field  className="logo"id="state" name="state" placeholder="state" />
        </div> 
        <div className='mb-5'>
        <label htmlFor="district" className='line text-white'>District <ErrorMessage name="district" component={'p'} className='error' /></label>
        <Field  className="logo"id="district" name="district" placeholder="district" />
        </div>
        <div className='d-flex justify-content-center gap-5 '>
         <button type="submit" className='px-5 bg1 text-white ' >SUBMIT</button>
         <button type='reset' className='px-5 bg1 text-white '>RESET</button>
        </div>



      </Form>
      </div>
    </Formik>

            </div>

        </div>
      
      
    </div>
  )
}

export default Contactcreact
