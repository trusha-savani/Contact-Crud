import React from 'react'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { Link } from 'react-router-dom/cjs/react-router-dom.min';

const NavBar = () => {
  return (
    <div>
       <Navbar expand="lg" className="my-3 rounded-2" style={{ backgroundColor: "black" }}>
                    <Container>
                        <Navbar.Brand><Link className="text-decoration-none text-black fs-4 text-white" to="/"> CONTACT API </Link></Navbar.Brand>
                        <Navbar.Toggle aria-controls="basic-navbar-nav" />
                        <Navbar.Collapse id="basic-navbar-nav">
                            <Nav className="ms-auto">
                                <NavDropdown title="USER" className='border border-black rounded mx-2 ' style={{ width: "160px" }} id="basic">
                                    <NavDropdown.Item> <Link className="text-decoration-none text-black" to="/"> SIGN UP </Link> </NavDropdown.Item>
                                    <NavDropdown.Divider />
                                    <NavDropdown.Item> <Link className="text-decoration-none text-black" to="/Userloginpage"> LOG IN </Link> </NavDropdown.Item>
                                </NavDropdown>
                                <NavDropdown title="ADMIN" className='border border-black rounded mx-2' style={{ width: "160px" }} id="basic">
                                    <NavDropdown.Item> <Link className="text-decoration-none text-black" to="/Adminsignuppage"> SIGN UP </Link> </NavDropdown.Item>
                                    <NavDropdown.Divider />
                                    <NavDropdown.Item> <Link className="text-decoration-none text-black" to="/Adminlogin"> LOG IN </Link> </NavDropdown.Item>
                                </NavDropdown>
                                <NavDropdown title="CONTACT" className='border border-black rounded mx-2' style={{ width: "160px" }} id="basic">
                                    <NavDropdown.Item> <Link className="text-decoration-none text-black" to="/Contactadmin"> CREATE CONTACT </Link> </NavDropdown.Item>
                                </NavDropdown>
                            </Nav>
                        </Navbar.Collapse>
                    </Container>
                </Navbar>
    </div>
  )
}

export default NavBar
