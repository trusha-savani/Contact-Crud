
import './App.css';

import 'bootstrap/dist/css/bootstrap.min.css';
import Usersignuppage from './Component/Usersignuppage';
import Userloginpage from './Component/Userloginpage';
import Adminsignuppage from './Component/Adminsignuppage';
import Adminlogin from './Component/Adminlogin';
import Contactcreact from './Component/Contactcreact';

import Contactadmin from './Component/Contactadmin';
import NavBar from './Component/NavBar';
import {
  BrowserRouter as Router,
  Switch,
  Route
  
} from "react-router-dom";



function App() {
  return (
    <div className="App">
      <Router>
    <NavBar />

        <Switch>
          <Route exact path="/">
          <Usersignuppage />
            </Route>
            <Route exact path="/Userloginpage">
            <Userloginpage />
            </Route>
            <Route exact path="/Adminsignuppage">
            <Adminsignuppage />
            </Route>
            <Route exact path="/Adminlogin">
            <Adminlogin />
            </Route>
            <Route exact path="/Contactadmin">
            <Contactadmin />
            </Route>
            
        </Switch>
      </Router>

      {/* <Usersignuppage />
      <Userloginpage />
      <Adminsignuppage />
      <Adminlogin />
      <Contactcreact /> 
      <Contactadmin /> */}
      

      
      
    </div>
  );
}

export default App;
