import React from 'react'
import { Formik, Field, Form,ErrorMessage  } from 'formik';
import * as Yup from "yup";
import axios from 'axios';
import AOS from 'aos';
import 'aos/dist/aos.css';
import { useEffect } from 'react';
import { Link } from 'react-router-dom/cjs/react-router-dom.min';


const SignupSchema = Yup.object().shape({
    firstname: Yup.string().min(2, 'Too Short!').max(70, 'Too Long!').required('Required'),
    lastname: Yup.string().min(2, 'Too Short!').max(70, 'Too Long!').required('Required'),
    email: Yup.string().email('Invalid email').required('Required'),
    contact: Yup.string().min(2, 'Too Short!').max(70, 'Too Long!').required('Required'),
    username: Yup.string().min(2, 'Too Short!').max(70, 'Too Long!').required('Required'),
    password: Yup.string().min(2, 'Too Short!').max(70, 'Too Long!').required('Required'),
});

const Usersignuppage = () => {
  useEffect(()=>{
    AOS.init();
  },[])
  return (
    <div>
        <div className='container'>
            <div className="container-fluid">
            <Formik
      initialValues={{
        firstname: '',
        lastname: '',
        email: '',
        contact:'',
        username:'',
        password:'',
    }}
      validationSchema={SignupSchema}
      onSubmit={async (values,action) => {

        axios.post("https://contact-api-lz03.onrender.com/api/user/signup",values)
        .then((res)=>{
            console.log(res);
            alert("User Login sucssesfully")
        })
        .catch((err)=>{
            console.log(err);
            alert("not valid")
        })
        action.resetForm()
      
      }}
    >
        <div className='w-100 d-flex align-items-center mt-10'>

        
      <Form className='border border-black back-side fs-5 'data-aos="fade-right">
        <div className='text-center text-black'>
            <h3>USER SIGN IN FORM</h3>

        </div>
        <div className='text-black mb-3'>
        <label htmlFor="firstname" className='line' >First Name <ErrorMessage name="firstname" component={'p'} className='error' /></label>
        <Field  className="logo" id="firstname" name="firstname" placeholder="firstname" />
        </div>
        <div  className='text-black mb-3'>
        <label htmlFor="lastname" className='line'>Last Name<ErrorMessage name="lastname" component={'p'} className='error' /></label>
        <Field  className="logo" id="lastname" name="lastname" placeholder="lastname" />
        </div>
        <div  className='text-black mb-3'>
        <label htmlFor="email" className='line' >Email<ErrorMessage name="email" component={'p'} className='error' /></label>
        <Field id="email" name="email" placeholder="jane@acme.com" type="email" className="logo" />
        </div>
        <div  className='text-black mb-3'>
        <label htmlFor="contact" className='line'>Contact <ErrorMessage name="contact" component={'p'} className='error' /></label>
        <Field  className="logo"id="contact" name="contact" placeholder="contact" />
        </div>
        <div  className='text-black mb-3'>
        <label htmlFor="username" className='line'>Username <ErrorMessage name="username" component={'p'} className='error' /></label>
        <Field  className="logo"id="username" name="username" placeholder="username" />
        </div>
        <div className='mb-5 text-black mb-3'>
        <label htmlFor="password" className='line'>Password <ErrorMessage name="password" component={'p'} className='error' /></label>
        <Field  className="logo"id="password" name="password" placeholder="password" />
        </div> 
        <div className='d-flex justify-content-center gap-5  '>
         <button type="submit" className='px-5 bg1 text-white rounded-5' style={{width:'100%'}} >SIGN UP</button>

        </div>
        <div className='mt-2'>
        <button type='reset' className='px-5 bg1 text-white  rounded-5'style={{width:'100%'}}>RESET</button>
        </div>
        <div className='d-flex align-items-center mt-2'>
          <input type="checkbox" />
          <p className='m-2'>i agree to the <strong className='text-primary'>Terms & Condition</strong>
          </p>
        </div>
        <div className='d-flex justify-content-center '>
          <p> Already have an account?<Link to='/Userloginpage' className='text-primary' >Login</Link></p>
        </div>



      </Form>
      </div>
    </Formik>

            </div>

        </div>
      
    </div>
  )
}

export default Usersignuppage
